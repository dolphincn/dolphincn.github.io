#!/bin/bash
/usr/bin/cp /mnt/data/mirror.list.kubernetes /etc/apt-mirror.list
/usr/sbin/apt-mirror
